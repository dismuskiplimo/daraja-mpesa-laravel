<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Make Donation')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <form action="" method = "POST">
                <?php echo csrf_field(); ?>

                <div class = "form-group flex flex-col mb-8">
                    <label for="donor-name" >Donor Name<span class = "text-red-600">*</span></label>
                    <input type="text" name = "donor_name" id = "donor-name" placeholder="John Doe" title = "Donor Name" value = "<?php echo e(old("donor_name")); ?>" required>
                </div>

                <div class = "form-group form-group flex flex-col mb-8">
                    <label for="phone">Telephone (07XXXXXXXX e.g. 0720123456)<span class = "text-red-600">*</span></label>
                    <input type="text" name = "phone" id = "phone" placeholder="07XXXXXXXX" pattern="0[0-9]{9}" title = "Phone Number" value = "<?php echo e(old("phone")); ?>" required>
                </div>

                <div class = "form-group form-group flex flex-col mb-8">
                    <label for="donation-type">Donation Type<span class = "text-red-600">*</span></label>
                    <select  name = "donation_type" id = "donation-type" title = "Donation Type" required>
                        <option <?php echo e(old('donation_type') != null && old('donation_type') == 'Tithe' ? 'selected' : ""); ?>>Tithe</option>
                        <option <?php echo e(old('donation_type') != null && old('donation_type') == 'Offertory' ? 'selected' : ""); ?>>Offertory</option>
                        <option <?php echo e(old('donation_type') != null && old('donation_type') == 'Church Development' ? 'selected' : ""); ?>>Church Development</option>
                        <option <?php echo e(old('donation_type') != null && old('donation_type') == 'Buy Pew' ? 'selected' : ""); ?>>Buy Pew</option>
                    </select>
                </div>
        
                <div class = "form-group form-group flex flex-col mb-8">
                    <label for="amount">Amount (Min: KES 5)<span class = "text-red-600">*</span></label>
                    <input type="number" name = "amount" min = "5" id = "amount" placeholder="500" title = "Amount" value = "<?php echo e(old("amount")); ?>" required>
                </div>

                <div class = "form-group form-group flex flex-col mb-8">
                    <label for="donor-note">Donor Note<span class = "text-red-600">*</span></label>
                    <textarea  name = "donor_note" id = "donor-note" title = "Donor Note" placeholder="Note" required><?php echo e(old("donor_note")); ?></textarea>
                </div>
        
                <button class="p-3 bg-gray-800 text-white" type="submit">Make Donation</button>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\daraja-mpesa-laravel\resources\views/pages/index.blade.php ENDPATH**/ ?>