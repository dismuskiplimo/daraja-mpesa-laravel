<?php if(Session::has('success')): ?>
	<div class="w-full bg-green-200 text-green-900">
		<div class="container mx-auto">
			<p><strong>Success!</strong>  <?php echo e(Session::get('success')); ?>.</p>
		</div>
	</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
	<div class="w-full bg-red-200 text-red-900">
		<div class="container mx-auto">
			<p><strong>Error!</strong> <?php echo e(Session::get('error')); ?>.</p>
		</div>
	</div>
<?php endif; ?>

<?php if(count($errors)): ?>
	<div class="w-full bg-red-200 text-red-900">
		<div class="container mx-auto">
			<ul>
				<p><strong>Error!</strong></p>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</ul>
		</div>
	</div>
<?php endif; ?><?php /**PATH C:\wamp64\www\daraja-mpesa-laravel\resources\views/includes/messages.blade.php ENDPATH**/ ?>