<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Donations')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <h2 class="text-center text-xl font-bold mb-8">Donations</h2>
            <table class="table-auto border-solid border border-slate-600">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Telephone</th>
                        <th>Donation Type</th>
                        <th>Amount (KES)</th>
                        <th>Note</th>
                        <th>MPESA Receipt Number</th>
                        <th>Payment Made</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="odd:bg-slate-200 even:bg-slate-100">
                            <td><?php echo e($donation->donor_name); ?></td>
                            <td><?php echo e($donation->phone); ?></td>
                            <td><?php echo e($donation->donation_type); ?></td>
                            <td><?php echo e($donation->amount); ?></td>
                            <td><?php echo e($donation->donor_note); ?></td>
                            <td><?php echo e($donation->mpesa_receipt_number); ?></td>
                            <td><?php echo $donation->fulfilled == '1' ? '<span class = "text-green-600">YES</span>' : '<span class = "text-red-600">NO</span>'; ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\daraja-mpesa-laravel\resources\views/pages/donations.blade.php ENDPATH**/ ?>